import{test,expect} from '@playwright/test'
import { SignUp } from '../pages/Signup'
import data from '../Utils/SignupCredential.json'

test('SignUp click ok',async({page})=>{
        await page.waitForLoadState('networkidle')

    //await page.goto('https://www.demoblaze.com/')
 const username=data.username
 const password=data.password
 const SignUpPage=new SignUp(page)
 await SignUpPage.navigateApplication()
 await SignUpPage.applicationSingup(username,password)

})

test('click close button in signup',async({page})=>{
    await page.waitForLoadState('networkidle')
     const username=data.username
     const password=data.password
     const ClickClosePage=new ClickClose(page)
     await SignUpPage.navigateApplication()
     await SignUpPage.applicationSingup(username,password)


})



