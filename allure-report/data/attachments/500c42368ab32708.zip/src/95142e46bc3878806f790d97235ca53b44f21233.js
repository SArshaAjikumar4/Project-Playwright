import{test,expect} from '@playwright/test'
import { LoginPage } from '../pages/LoginPage'
import data from '../Utils/Logincredential.json'



test('Valid username and password',async({page})=>{
    await page.waitForLoadState('networkidle')
    const validusername=data.validusername
    const validpassword=data.validpassword

    const Loginpage=new LoginPage(page)
    await Loginpage.naviagteApplication()
    await Loginpage.loginApplication(validusername,validpassword)
    await LoginPage.verifingApplication()

    
})

test('valid username and invalid password',async({page})=>{
    const validusername=data.validusername
    const invalidpassword=data.invalidpassword
    const Loginpage=new LoginPage(page)
    await Loginpage.naviagteApplication()
    await Loginpage.loginApplication(validusername,invalidpassword)
})

test('invalid username and valid password',async({page})=>{
    const invalidusername=data.invalidusername
    const validpassword=data.validpassword
    const Loginpage=new LoginPage(page)
    await Loginpage.naviagteApplication()
    await Loginpage.loginApplication(invalidusername,validpassword)
})

test('invalid username and invalid password',async({page})=>{
    const invalidusername=data.invalidusername
    const invalidpassword=data.invalidpassword
    const Loginpage=new LoginPage(page)
    await Loginpage.naviagteApplication()
    await Loginpage.loginApplication(invalidusername,invalidpassword)
})
