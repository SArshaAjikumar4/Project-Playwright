import{test,expect} from '@playwright/test'
import { LoginPage } from '../pages/LoginPage'
import { PurchasePage } from '../pages/PurchasePage'
import data from '../Utils/Logincredential.json'



test('Adding product to the cart',async({page})=>{
    const validusername=data.validusername
    const validpassword=data.validpassword
    const loginPage=new LoginPage(page)
    await loginPage.naviagteApplication()
    await loginPage.loginApplication(validusername,validpassword)
    
    const purchasePage=new PurchasePage(page)
    await purchasePage.clickAnyPoduct()


})