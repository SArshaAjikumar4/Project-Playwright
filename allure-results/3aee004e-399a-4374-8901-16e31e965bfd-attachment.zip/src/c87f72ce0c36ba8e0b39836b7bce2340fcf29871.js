import { test,expect } from '@playwright/test'
import { LoginPage } from '../pages/LoginPage'
import data from '../Utils/Logincredential.json'
import{AddToCartPage} from '../pages/AddToCartPage'



test('Add product to the cart',async({page})=>{
    const validusername=data.validusername
    const validpassword=data.validpassword


    const loginPage=new LoginPage(page)
    await loginPage.naviagteApplication()
    await loginPage.loginApplication(validusername,validpassword)
    
    const addToCartPage=new AddToCartPage(page)
    await addToCartPage.clickProduct()
    await addToCartPage.clickAddToCarts()

//POPUP
     page.on('dialog',async dialog=>{
        expect(dialog.message()).toBe('Product added.')
        await dialog.accept()
        const clickOk=page.locator('.col-sm-12 col-md-6 col-lg-6')
        await clickOk.click()

    })




})