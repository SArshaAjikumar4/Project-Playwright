import { expect } from '@playwright/test'
export class PurchasePage{
    constructor(page){
        this.page=page
        this.clickCategoryPhone=page.locator("//a[text()='Phones']")
        this.selectPhone=page.locator("//a[text()='Samsung galaxy s6']")
        this.clickCart=page.locator("//a[text()='Cart']")
        this.clickPlaceOrder=page.locator("//button[text()='Place Order']")
        this.nameField=page.locator('#name')
        this.countryField=page.locator('#country')
        this.cityField=page.locator('#city')
        this.creditcardField=page.locator('#card')
        this.monthField=page.locator('#month')
        this.yearField=page.locator('year')

        

    }

    
    

   /*async verifyingApplication(){
        await expect(this.page).toHaveURL('https://www.demoblaze.com/')

    }*/

    

    async selectAnyPhone(){
        await this.clickCategoryPhone.click()
        await this.selectPhone.click()
    }

    async navigateToCart(){
        await this.clickCart.click()
    }

    async placeOrder(){
        await this.clickPlaceOrder.click()
    }

    async detailsAdding(name,country,city,credirtcard,month,year){
        await this.nameField.fill(name)
        await this.countryField.fill(country)
        await this.cityField.fill(city)
        await this.creditcardField.fill(credirtcard)
        await this.monthField.fill(month)
        await this.yearField.fill(year)
    }
}