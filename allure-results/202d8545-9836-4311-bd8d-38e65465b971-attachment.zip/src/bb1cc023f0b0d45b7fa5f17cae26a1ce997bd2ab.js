import{test,expect} from '@playwright/test'
import { LoginPage } from '../pages/LoginPage'
import { PurchasePage } from '../pages/PurchasePage'
import data from '../Utils/Logincredential.json'
import Detailsdata from '../Utils/Detailscredential.json'





 test('Select product under phone',async({page})=>{

     //LOGIN
    const validusername=data.validusername
    const validpassword=data.validpassword
    const loginPage=new LoginPage(page)
    await loginPage.naviagteApplication()
    await loginPage.loginApplication(validusername,validpassword)
    

    //SELECT PHONE PRODUCT AND ADD TO CART And Purchase it
    const purchasePage=new PurchasePage(page)
   
    await purchasePage.selectAnyPhone()
    await purchasePage.clickAddToCarts()

    //POPUP Handling
    page.on('dialog',async dialog=>{
        expect(dialog.message()).toBe('Product added.')
        await dialog.accept()
        const clickOk=page.locator('.col-sm-12 col-md-6 col-lg-6')
        await clickOk.click()
    //Adding details

        const name=Detailsdata.name
        const country=Detailsdata.country
        const city=Detailsdata.city
        const credirtcard=Detailsdata.creditcard
        const month=Detailsdata.month
        const year=Detailsdata.year
        await purchasePage.navigateToCart()
        await purchasePage.detailsAdding(name,country,city,credirtcard,month,year)
    


    })





   


    })

 




