import { expect } from '@playwright/test'
export class SignUp{
    constructor(page){
        this.page=page
        this.clickSignup=page.locator("#signin2")
        this.usernameField=page.locator("#sign-username")
        this.passwordField=page.locator("#sign-password")
        this.clickSignup=page.locator(".btn btn-primary")
        
    }
    //methods create


    async navigateApplication(){
        await this.page.goto('https://www.demoblaze.com/')
        await this.clickSignup.click()
    }

    async applicationSingup(username,password){
        await this.usernameField.fill(username)
        await this.passwordField.fill(password)
        await this.clickSignup.click()

    }
}