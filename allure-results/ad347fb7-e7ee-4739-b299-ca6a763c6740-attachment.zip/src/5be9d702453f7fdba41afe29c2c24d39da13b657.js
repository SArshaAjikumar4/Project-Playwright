import { expect } from '@playwright/test'
export class PurchasePage{
    constructor(page){
        this.page=page
        this.clickLoginPage=page.locator('#login2')
        this.usernameField=page.locator('#loginusername')
        this.passwordField=page.locator('#loginpassword')
        this.clickLogin=page.locator("//button[text()='Log in']")
        this.clickAnyPoduct=page.locator("//a[text()='Iphone 6 32gb']")
        this.clickAddToCart=page.locator("//a[text()='Add to cart']")
        this.clickHome=page.locator('.nav-link')
        this.clickCategoryPhone=page.locator("//a[text()='Phones']")
        this.selectPhone=page.locator("//a[text()='Samsung galaxy s6']")
        

    }

    async naviagteApplication(){
         await this.page.goto('https://www.demoblaze.com/')
         await this.clickLoginPage.click()

    }

    async loginApplication(username,password){
        await this.usernameField.fill(username)
        await this.passwordField.fill(password)
        await this.clickLogin.click()

    }

   /*async verifyingApplication(){
        await expect(this.page).toHaveURL('https://www.demoblaze.com/')

    }*/

    async clickProduct(){
        await this.clickAnyPoduct.click()
    }

    async clickAddToCarts(){
        await this.clickAddToCart.click()
    }

    async  navigateToHome(){
        await this.clickHome.click()
    }

    async SelectAnyPhone(){
        await this.clickCategoryPhone.click()
        await this.selectPhone.click()
    }
}