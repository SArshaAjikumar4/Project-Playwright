import{test,expect} from '@playwright/test'
import { LoginPage } from '../pages/LoginPage'
import { PurchasePage } from '../pages/PurchasePage'
import data from '../Utils/Logincredential.json'



test('Adding product to the cart',async({page})=>{

    //LOGIN
    const validusername=data.validusername
    const validpassword=data.validpassword
    const loginPage=new LoginPage(page)
    await loginPage.naviagteApplication()
    await loginPage.loginApplication(validusername,validpassword)
    

    //SELECT ANY PRODUCT AND ADD TO CART
    const purchasePage=new PurchasePage(page)
    await purchasePage.clickProduct()
    await purchasePage.clickAddToCarts()

    //POPUP Handling
    page.on('dialog',async dialog=>{
        expect(dialog.message()).toBe('Product added.')
        await dialog.accept()
        const clickOk=page.locator('.col-sm-12 col-md-6 col-lg-6')
        await clickOk.click()


    })

})


 test('Select product under phone and Monitr',async({page})=>{
     //LOGIN
    const validusername=data.validusername
    const validpassword=data.validpassword
    const loginPage=new LoginPage(page)
    await loginPage.naviagteApplication()
    await loginPage.loginApplication(validusername,validpassword)
    

    //SELECT PHONE PRODUCT AND MONITOR THEN  ADD TO CART
    const purchasePage=new PurchasePage(page)
    await purchasePage.clickCategoryPhone()
    await purchasePage.SelectAnyPhone()
    await purchasePage.clickAddToCarts()

    //POPUP Handling
    page.on('dialog',async dialog=>{
        expect(dialog.message()).toBe('Product added.')
        await dialog.accept()
        const clickOk=page.locator('.col-sm-12 col-md-6 col-lg-6')
        await clickOk.click()


    })





   


    })

 




